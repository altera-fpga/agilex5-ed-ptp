/*********************************************************************************
 * **                                                                           **
 * ** ALTERA CONFIDENTIAL                                                       **
 * **                                                                           **
 * ** Copyright 2024 Altera/ALTERA Corporation All Rights Reserved.             **
 * **                                                                           **
 * ** The source code contained or described herein and all documents related   **
 * ** to the source code ("Material") are owned by Altera Corporation or its    **
 * ** suppliers or licensors.  Title to the Material remains with Altera        **
 * ** Corporation or its suppliers and licensors.  The Material contains trade  **
 * ** secrets and proprietary and confidential information of Altera or its     **
 * ** suppliers and licensors.  The Material is protected by worldwide          **
 * ** copyright and trade secret laws and treaty provisions.  No part of the    **
 * ** Material may be used, copied, reproduced, modified, published, uploaded,  **
 * ** posted, transmitted, distributed, or disclosed in any way without Altera's**
 * ** prior express written permission.                                         **
 * **                                                                           **
 * ** No license under any patent, copyright, trade secret or other             **
 * ** intelectual property right is granted to or conferred upon you by         **
 * ** disclosure or delivery of the Materials, either expressly, by             **
 * ** implication, inducement, estoppel or otherwise.  Any license under such   **
 * ** intelectual property rights must be express and approved by Altera in     **
 * ** writing.                                                                  **
 * **                                                                           **
 * ** Application - Packet Generator v1.0                                       **
 * ** Author - Krishna Kumar S R                                                **
 * ******************************************************************************/
#ifndef __PKTGEN_REISTER_MAP_H__
#define __PKTGEN_REISTER_MAP_H__

#include <string.h>
#include <stdint.h>
#include <stdbool.h>
#include <netinet/in.h> // For struct in_addr and struct in6_addr
#include <arpa/inet.h>  // For inet_pton and inet_ntop

#define SUCCESS	0
#define FAILURE	(-1)

typedef uint64_t uint64;
typedef uint32_t uint32;
typedef uint16_t uint16;
typedef uint8_t uint8;

#pragma pack(push, 1)
typedef union {
	struct {
		uint32 high;
		uint32 low;
	} val;
	struct {
		uint8 byte_1;
		uint8 byte_0;
		uint8 res_1;
		uint8 res_2;
		uint8 byte_5;
		uint8 byte_4;
		uint8 byte_3;
		uint8 byte_2;
	} mac;
} mac_address;
#pragma pack(pop)

#define SIZE_OF_IPV4_ADDRESS	sizeof(struct in_addr)
typedef union {
    struct in_addr ipv4;  // IPv4 address structure
    struct in6_addr ipv6; // IPv6 address structure
} ip_address;

#define PKTGEN_BIT_MASK	0x1
#define PKTGEN_2BIT_MASK 0x3
#define PKTGEN_8BIT_MASK 0xFF

#define PKTGEN_CONFIG_CONTROL_TX_TRAFFIC_MASK		0x1
#define PKTGEN_CONFIG_CONTROL_TX_TRAFFIC_ENABLE		0x1
#define PKTGEN_CONFIG_CONTROL_TX_TRAFFIC_GET(x)		((x) & PKTGEN_BIT_MASK)
#define PKTGEN_CONFIG_CONTROL_TX_TRAFFIC_SET(x)		((x) |= PKTGEN_CONFIG_CONTROL_TX_TRAFFIC_ENABLE)
#define PKTGEN_CONFIG_CONTROL_TX_TRAFFIC_RESET(x)	((x) &= ~PKTGEN_CONFIG_CONTROL_TX_TRAFFIC_ENABLE)

#define PKTGEN_CONFIG_CONTROL_ONE_SHOT_MODE_MASK	0x4
#define PKTGEN_CONFIG_CONTROL_CONTINUOUS_MODE_ENABLE 	0x1
#define PKTGEN_CONFIG_CONTROL_ONE_SHOT_MODE_GET(x)	((x) & PKTGEN_BIT_MASK)
#define PKTGEN_CONFIG_CONTROL_ONE_SHOT_MODE_SET(x)	((x) &= ~PKTGEN_CONFIG_CONTROL_CONTINUOUS_MODE_ENABLE)
#define PKTGEN_CONFIG_CONTROL_CONTINUOUS_MODE_SET(x)	((x) |= PKTGEN_CONFIG_CONTROL_CONTINUOUS_MODE_ENABLE)

#define PKTGEN_CONFIG_CONTROL_SOFT_RESET_MASK		0x8
#define PKTGEN_CONFIG_CONTROL_SOFT_RESET_ENABLE		0x1
#define PKTGEN_CONFIG_CONTROL_SOFT_RESET_GET(x)         ((x) & PKTGEN_BIT_MASK)
#define PKTGEN_CONFIG_CONTROL_SOFT_RESET_SET(x)         ((x) |= PKTGEN_CONFIG_CONTROL_SOFT_RESET_ENABLE)
#define PKTGEN_CONFIG_CONTROL_SOFT_RESET_RESET(x)       ((x) &= ~PKTGEN_CONFIG_CONTROL_SOFT_RESET_ENABLE)

#define PKTGEN_CONFIG_CONTROL_DYNAMIC_MODE_MASK		0x10
#define PKTGEN_CONFIG_CONTROL_DYNAMIC_MODE_ENABLE	0x1
#define PKTGEN_CONFIG_CONTROL_DYNAMIC_MODE_GET(x)         ((x) & PKTGEN_BIT_MASK)
#define PKTGEN_CONFIG_CONTROL_DYNAMIC_MODE_SET(x)         ((x) |= PKTGEN_CONFIG_CONTROL_DYNAMIC_MODE_ENABLE)
#define PKTGEN_CONFIG_CONTROL_DYNAMIC_MODE_RESET(x)       ((x) &= ~PKTGEN_CONFIG_CONTROL_DYNAMIC_MODE_ENABLE)

#define PKTGEN_CONFIG_CONTROL_PKT_CHECKER_MASK		0x20
#define PKTGEN_CONFIG_CONTROL_PKT_CHECKER_ENABLE	0x1
#define PKTGEN_CONFIG_CONTROL_PKT_CHECKER_GET(x)         ((x) & PKTGEN_BIT_MASK)
#define PKTGEN_CONFIG_CONTROL_PKT_CHECKER_SET(x)         ((x) |= PKTGEN_CONFIG_CONTROL_PKT_CHECKER_ENABLE)
#define PKTGEN_CONFIG_CONTROL_PKT_CHECKER_RESET(x)       ((x) &= ~PKTGEN_CONFIG_CONTROL_PKT_CHECKER_ENABLE)

#define PKTGEN_CONFIG_CONTROL_CNTR_SNAPSHOT_MASK	0x40
#define PKTGEN_CONFIG_CONTROL_CNTR_SNAPSHOT_ENABLE	0x1
#define PKTGEN_CONFIG_CONTROL_CNTR_SNAPSHOT_GET(x)         ((x) & PKTGEN_BIT_MASK)
#define PKTGEN_CONFIG_CONTROL_CNTR_SNAPSHOT_SET(x)         ((x) |= PKTGEN_CONFIG_CONTROL_CNTR_SNAPSHOT_ENABLE)
#define PKTGEN_CONFIG_CONTROL_CNTR_SNAPSHOT_RESET(x)       ((x) &= ~PKTGEN_CONFIG_CONTROL_CNTR_SNAPSHOT_ENABLE)

#define PKTGEN_CONFIG_CONTROL_CNTR_CLEAR_MASK		0x80
#define PKTGEN_CONFIG_CONTROL_CNTR_CLEAR_ENABLE		0x1
#define PKTGEN_CONFIG_CONTROL_CNTR_CLEAR_GET(x)         ((x) & PKTGEN_BIT_MASK)
#define PKTGEN_CONFIG_CONTROL_CNTR_CLEAR_SET(x)         ((x) |= PKTGEN_CONFIG_CONTROL_CNTR_CLEAR_ENABLE)
#define PKTGEN_CONFIG_CONTROL_CNTR_CLEAR_RESET(x)       ((x) &= ~PKTGEN_CONFIG_CONTROL_CNTR_CLEAR_ENABLE)

#define PKTGEN_CONFIG_CONTROL_CNTR_INTERNAL_CLEAR_MASK		0x100
#define PKTGEN_CONFIG_CONTROL_CNTR_INTERNAL_CLEAR_ENABLE	0x1
#define PKTGEN_CONFIG_CONTROL_CNTR_INTERNAL_CLEAR_GET(x)         ((x) & PKTGEN_BIT_MASK)
#define PKTGEN_CONFIG_CONTROL_CNTR_INTERNAL_CLEAR_SET(x)         ((x) |= PKTGEN_CONFIG_CONTROL_CNTR_INTERNAL_CLEAR_ENABLE)
#define PKTGEN_CONFIG_CONTROL_CNTR_INTERNAL_CLEAR_RESET(x)       ((x) &= ~PKTGEN_CONFIG_CONTROL_CNTR_INTERNAL_CLEAR_ENABLE)

#define PKTGEN_CONFIG_CONTROL_FIXED_GAP_MASK		0x200
#define PKTGEN_CONFIG_CONTROL_FIXED_GAP_ENABLE		0x1
#define PKTGEN_CONFIG_CONTROL_FIXED_GAP_GET(x)         ((x) & PKTGEN_BIT_MASK)
#define PKTGEN_CONFIG_CONTROL_FIXED_GAP_SET(x)         ((x) |= PKTGEN_CONFIG_CONTROL_FIXED_GAP_ENABLE)
#define PKTGEN_CONFIG_CONTROL_FIXED_GAP_RESET(x)       ((x) &= ~PKTGEN_CONFIG_CONTROL_FIXED_GAP_ENABLE)

#define PKTGEN_CONFIG_CONTROL_PKT_LENGTH_MODE_MASK		0xC00
#define PKTGEN_CONFIG_CONTROL_PKT_LENGTH_MODE_FIXED_LENGTH	0x1
#define PKTGEN_CONFIG_CONTROL_PKT_LENGTH_MODE_INCR_LENGTH	0x2
#define PKTGEN_CONFIG_CONTROL_PKT_LENGTH_MODE_GET(x)         ((x) & PKTGEN_2BIT_MASK)

#define PKTGEN_CONFIG_CONTROL_NUM_IDLE_CYCLES_MASK		0xFF000
#define PKTGEN_CONFIG_CONTROL_NUM_IDLE_CYCLES_GET(x)         ((x) & PKTGEN_8BIT_MASK)

#pragma pack(push, 1)
typedef union {
	uint32 value;
	struct {
		uint32 tx_traffic:1;
		uint32 reserved_1:1;
		uint32 one_shot_mode:1;
		uint32 pktgen_soft_reset:1;
		uint32 dynamic_mode_pktgen:1;
		uint32 pkt_checker:1;
		uint32 cntr_snapshot:1;
		uint32 cntr_clear:1;
		uint32 cntr_internal_clear:1;
		uint32 fixed_gap:1;
		uint32 pkt_length_mode:2;
		uint32 num_idle_cycles:8;
		uint32 reserved_3:12;
	} genconfig;
} pktGenConfigControl_t;
#pragma pack(pop)

#define PKTGEN_PKTSIZE_CONFIG_TX_PACKET_SIZE_MASK	0x3FFF
#define PKTGEN_PKTSIZE_CONFIG_TX_PACKET_SIZE_GET(x)	((x)&PKTGEN_PKTSIZE_CONFIG_TX_PACKET_SIZE_MASK)

#pragma pack(push, 1)
typedef union {
	uint32 value;
	struct {
		uint32 tx_packet_size:14;
		uint32 reserved_1:2;
		uint32 tx_packet_size_max:14;
		uint32 reserved_2:2;
	} sizecfg;
} pktGenPktSizeConfig_t;
#pragma pack(pop)

typedef struct {
	uint32 low;
	uint32 high;
} pktGenStatistics_t;

#define PKTGEN_SYSTEM_STATUS_SADB_CONFIG_MASK			0x01
#define PKTGEN_SYSTEM_STATUS_SADB_CONFIG_COMPLETE		0x01
#define PKTGEN_SYSTEM_STATUS_SADB_CONFIG_GET(x)		((x) & PKTGEN_BIT_MASK)

#define PKTGEN_SYSTEM_STATUS_SYSTEM_RESET_SEQUENCE_MASK			0x02
#define PKTGEN_SYSTEM_STATUS_SYSTEM_RESET_SEQUENCE_COMPLETE		0x01
#define PKTGEN_SYSTEM_STATUS_SYSTEM_RESET_SEQUENCE_GET(x)		((x) & PKTGEN_BIT_MASK)

#define PKTGEN_SYSTEM_STATUS_TX_LANE_STATUS_MASK		0x04
#define PKTGEN_SYSTEM_STATUS_TX_LANE_STATUS_ASSERT		0x01
#define PKTGEN_SYSTEM_STATUS_TX_LANE_STATUS_GET(x)		((x) & PKTGEN_BIT_MASK)

#define PKTGEN_SYSTEM_STATUS_TX_PLL_LOCK_MASK		0x08
#define PKTGEN_SYSTEM_STATUS_TX_PLL_LOCKED		0x01
#define PKTGEN_SYSTEM_STATUS_TX_PLL_LOCK_GET(x)		((x) & PKTGEN_BIT_MASK)

#define PKTGEN_SYSTEM_STATUS_RX_PCS_READY_MASK		0x10
#define PKTGEN_SYSTEM_STATUS_RX_PCS_READY		0x01
#define PKTGEN_SYSTEM_STATUS_RX_PCS_READY_GET(x)		((x) & PKTGEN_BIT_MASK)

#pragma pack(push, 1)
typedef union {
	uint32 value;
	struct {
		uint32 sadb_config:1;
		uint32 sysreset:1;
		uint32 tx_lane:1;
		uint32 tx_pll:1;
		uint32 rx_pcs:1;
		uint32 reserved:27;

	} genstatus;
} pktGenStatus_t;
#pragma pack(pop)

#define PKTGEN_CHECKER_STATUS_DATA_MISMATCH_MASK          0x1
#define PKTGEN_CHECKER_STATUS_DATA_MISMATCH_ASSERT        0x01
#define PKTGEN_CHECKER_STATUS_DATA_MISMATCH_GET(x)                ((x) & PKTGEN_CHECKER_STATUS_DATA_MISMATCH_MASK)

#pragma pack(push, 1)
typedef struct {
	uint32 data_mismatch:1;
	uint32 reserved:30;
} pktGenCheckerStatus_t;
#pragma pack(pop)

#pragma pack(push, 1)
typedef struct {
	pktGenConfigControl_t	config;
	uint32 reserved_1[2];
	mac_address dynamic_dest_mac_addr;	
	mac_address dynamic_src_mac_addr;	
	uint32 num_packets;
	pktGenPktSizeConfig_t pkt_size_config;
	pktGenStatistics_t tx_sop_cnt;
	pktGenStatistics_t tx_eop_cnt;
	pktGenStatistics_t tx_err_cnt;
	pktGenStatistics_t rx_sop_cnt;
	pktGenStatistics_t rx_eop_cnt;
	pktGenStatistics_t rx_err_cnt;
	pktGenStatus_t	misc_status;
	pktGenCheckerStatus_t checker_status;
	uint32 checker_stats;
	pktGenStatistics_t pktcli_rx_byte_cnt;
	pktGenStatistics_t pktcli_tx_byte_cnt;
	pktGenStatistics_t pktcli_tx_ticks_cnt;
	pktGenStatistics_t pktcli_rx_ticks_cnt;
	uint32 reserved_2[1];
	pktGenStatistics_t txBandwidth;
	pktGenStatistics_t rxBandwidth;
	uint32 num_words;
} packetgen_t;
#pragma pack(pop)

void dumpPktGenStructure(packetgen_t *pktgen);
#endif // __PKTGEN_REISTER_MAP_H__
