/*********************************************************************************
 * **                                                                           **
 * ** ALTERA CONFIDENTIAL                                                       **
 * **                                                                           **
 * ** Copyright 2024 Altera/ALTERA Corporation All Rights Reserved.             **
 * **                                                                           **
 * ** The source code contained or described herein and all documents related   **
 * ** to the source code ("Material") are owned by Altera Corporation or its    **
 * ** suppliers or licensors.  Title to the Material remains with Altera        **
 * ** Corporation or its suppliers and licensors.  The Material contains trade  **
 * ** secrets and proprietary and confidential information of Altera or its     **
 * ** suppliers and licensors.  The Material is protected by worldwide          **
 * ** copyright and trade secret laws and treaty provisions.  No part of the    **
 * ** Material may be used, copied, reproduced, modified, published, uploaded,  **
 * ** posted, transmitted, distributed, or disclosed in any way without Altera's**
 * ** prior express written permission.                                         **
 * **                                                                           **
 * ** No license under any patent, copyright, trade secret or other             **
 * ** intelectual property right is granted to or conferred upon you by         **
 * ** disclosure or delivery of the Materials, either expressly, by             **
 * ** implication, inducement, estoppel or otherwise.  Any license under such   **
 * ** intelectual property rights must be express and approved by Altera in     **
 * ** writing.                                                                  **
 * **                                                                           **
 * ** Application - Packet Generator v1.0                                       **
 * ** Author - Krishna Kumar S R                                                **
 * ******************************************************************************/
#include <errno.h>
#include <inttypes.h>
#include <stddef.h>
#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdint.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/timeb.h>
#include <time.h>
#include <string.h>
#include <getopt.h>
#include <arpa/inet.h>
#include "packetgenRegisterMap.h"
#include "packetgenRegisterInterface.h"
#include <stdbool.h>

#define DEFAULT_WIDTH 4
#define PROGRAM_NAME "pktgen"
#define PKTGEN_MAP_SIZE	sizeof(packetgen_t)

//Parse a host of bool input values.
int parse_bool(bool *val, const char *str) {
	if ((strcmp(str, "true") == 0) || (strcmp(str, "1") == 0) || (strcmp(str, "enabled")==0) || 
		(strcmp(str, "enable")==0) || (strcmp(str, "start") == 0)) {
		*val = true;
		return SUCCESS;
	} else if ((strcmp(str, "false") == 0) || (strcmp(str, "0") == 0) || (strcmp(str, "disabled")==0) || 
			   (strcmp(str, "disable")==0) || (strcmp(str, "stop") == 0)) {
		*val = false;
		return SUCCESS;
	} else {
		fprintf(stderr, "Invalid boolean value: %s\n", str);
		return FAILURE;
	}
	return FAILURE;
}
// Enumeration for packet generator operations
typedef enum operation {
	PKTGEN_OPR_DUMP,
	PKTGEN_OPR_REGISTER_READ,
	PKTGEN_OPR_REGISTER_WRITE,
	PKTGEN_OPR_MAX,
} operation_t;

// Array of command-line options for the packet generator
static struct option long_options[] = {
    {"help",    	no_argument,       0, 'h'},
    {"device",          required_argument, 0, 'd'},
    {"dump", 		no_argument,	   0, 'x'},
    {"register-offset", required_argument, 0, 0},
    {"register-value", 	required_argument, 0, 0},
    {"dest-mac",	required_argument, 0, 0},
    {"src-mac",		required_argument, 0, 0},
    {"traffic",   	required_argument, 0, 0},
    {"one-shot",   	required_argument, 0, 0},
    {"soft-reset",      no_argument,0, 0},
    {"packet-checker",	required_argument, 0, 0},
    {"cntr-snapshot",	required_argument, 0, 0},
    {"cntr-clear",	required_argument, 0, 0},
    {"cntr-internal-clear",	required_argument, 0, 0},
    {"fixed-gap",	required_argument, 0, 0},
    {"pkt-len-mode",	required_argument, 0, 0},
    {"num-idle-cycles", required_argument, 0, 0},
    {"tx-pkt-size",  	required_argument, 0, 0},
    {"tx-max-pkt-size", required_argument, 0, 0},
    {"num-packets", 	required_argument, 0, 0},
    {0, 0, 0, 0} // End of array need to be filled with zeros
};

// Function to display usage information
static void usage(int exit_status) {
    fprintf(exit_status == EXIT_SUCCESS ? stdout : stderr,
        "Packet generator Interface. Usage: %s [--device] [/dev/uioX] [options]\n"
        "\n"
        "Functions:\n"
	"\tSet/Reset functionalities in the pktgen IP to generate packets\n"
	"\tDump all registers of pktgen\n"
	"\tRegister read/write interface"
        "\n"
	"Options:\n"
	"  --help			\t Print this help contents\n"
	"  --device           		\t uio device name\n"
	"  --dump            	 	\t Dump all register contents\n"
	"  --register-offset <offset> 	\t 32b alligned register offset to do direct register read/write\n"
	"  --register-value  <value>  	\t 32b Value to be written to the register\n"
	"  --dest-mac <mac-address>	\t Destination Mac address in the packet\n"
	"  --src-mac <mac-address>	\t Source Mac address in the packet\n"
	"  --traffic <bool>         	\t Enable or disable traffic\n"
	"  --one-shot <bool>         	\t Enable or disable one shot mode.\n"
	"  --soft-reset			\t trigger a soft reset\n"
	"  --packet-checker <bool>   	\t Enable or disable packet checker\n"
	"  --cntr-snapshot <bool>   	\t Take a counter snapshot \n"
	"  --cntr-clear  <bool>      	\t Clear all counter CSRs\n"
	"  --cntr-internal-clear <bool>	\t Clear all internal counters\n"
	"  --fixed-gap <bool>        	\t Enable or disable Fixed gap between packets\n"
	"  --pkt-len-mode <value>     	\t Set Packet generation length mode Fixed/Incremental [1,2]\n"
	"  --num-idle-cycles  <value> 	\t Number of Idle cycles to insert [0...255]\n"
	"  --tx-pkt-size   <value>    	\t TX packet size [64...9216]. Alligned to the data bus width.\n"
	"  --tx-max-pkt-size  <value> 	\t Maximum TX packet size [64...9216]. Alligned to the data bus width.\n"
	"  --num-packets  <value> 	\t Number of packets to generate [0...0xFFFFFFFF]\n"
	,
	    PROGRAM_NAME);
}

/**
 * @brief The main function of the program.
 *
 * This function is the entry point of the program. It is called automatically
 * when the program starts running. The main function is responsible for
 * executing the program logic and returning an exit status to the operating
 * system.
 *
 * @param argc The number of command-line arguments passed to the program.
 * @param argv An array of strings containing the command-line arguments.
 * @return An integer representing the exit status of the program.
 */
int main(int argc, char *argv[]) 
{
	int fd=0, exitResult = EXIT_SUCCESS;
	char *fpath;
	packetgen_t *ptr = MAP_FAILED;
	int map_size=PKTGEN_MAP_SIZE, value=0;
	int opt = 0;
	int option_index = 0;
	bool cliOption = false;
	uint32 wait = 0;
	uint32 registerAddress = 0x0;
	operation_t opr = PKTGEN_OPR_MAX;
	uint32 num_words = 0;

	//First parse the device option so that we can open the device and keep it ready. After that we can
	//parse other options and set the corresponding registers
	while ((opt = getopt_long(argc, argv, "hd:xsr", long_options, &option_index)) != -1) {
		if (option_index == 0) {
			usage(EXIT_SUCCESS);
			return SUCCESS;
		} else if (option_index == 1) {
			fpath = optarg;
			map_size = PKTGEN_MAP_SIZE;

			fd = open(fpath, O_RDWR|O_SYNC);
			if (fd < 1) {
				perror(PROGRAM_NAME);
				fprintf(stderr, "Couldn't open UIO device file: %s\n", fpath);
				return EXIT_FAILURE;
			}
			ptr = mmap(NULL, map_size, PROT_READ|PROT_WRITE,
					MAP_SHARED, fd, 0);
			if (ptr == MAP_FAILED) {
				perror("mmap error");
				fprintf(stderr, "Couldn't mmap.\n");
				return EXIT_FAILURE;
			}
			break;
		}
	}

	if (fd < 1 || ptr == MAP_FAILED) {
		perror(PROGRAM_NAME);
		fprintf(stderr, "Device name should be provided\n");
		usage(EXIT_SUCCESS);
	}

#if DEBUG
	printf("Offset of config: 0x%lX\n", offsetof(packetgen_t, config));
	printf("Offset of dynamic_dest_mac_addr: 0x%lX\n", offsetof(packetgen_t, dynamic_dest_mac_addr));
	printf("Offset of dynamic_src_mac_addr: 0x%lX\n", offsetof(packetgen_t, dynamic_src_mac_addr));
	printf("Offset of num_packets: 0x%lX\n", offsetof(packetgen_t, num_packets));
	printf("Offset of pkt_size_config: 0x%lX\n", offsetof(packetgen_t, pkt_size_config));
	printf("Offset of tx_sop_cnt: 0x%lX\n", offsetof(packetgen_t, tx_sop_cnt));
	printf("Offset of tx_eop_cnt: 0x%lX\n", offsetof(packetgen_t, tx_eop_cnt));
	printf("Offset of tx_err_cnt: 0x%lX\n", offsetof(packetgen_t, tx_err_cnt));
	printf("Offset of rx_sop_cnt: 0x%lX\n", offsetof(packetgen_t, rx_sop_cnt));
	printf("Offset of rx_eop_cnt: 0x%lX\n", offsetof(packetgen_t, rx_eop_cnt));
	printf("Offset of rx_err_cnt: 0x%lX\n", offsetof(packetgen_t, rx_err_cnt));
	printf("Offset of misc_status: 0x%lX\n", offsetof(packetgen_t, misc_status));
	printf("Offset of checker_status: 0x%lX\n", offsetof(packetgen_t, checker_status));
	printf("Offset of checker_stats: 0x%lX\n", offsetof(packetgen_t, checker_stats));
	printf("Offset of pktcli_rx_byte_cnt: 0x%lX\n", offsetof(packetgen_t, pktcli_rx_byte_cnt));
	printf("Offset of pktcli_tx_byte_cnt: 0x%lX\n", offsetof(packetgen_t, pktcli_tx_byte_cnt));
	printf("Offset of pktcli_tx_ticks_cnt: 0x%lX\n", offsetof(packetgen_t, pktcli_tx_ticks_cnt));
	printf("Offset of pktcli_rx_ticks_cnt: 0x%lX\n", offsetof(packetgen_t, pktcli_rx_ticks_cnt));
	printf("Offset of txBandwidth: 0x%lX\n", offsetof(packetgen_t, txBandwidth));
	printf("Offset of rxBandwidth: 0x%lX\n", offsetof(packetgen_t, rxBandwidth));   
#endif
	num_words = ptr->num_words;
	if (num_words < 1 || num_words > 4)
		num_words = 1;
	// Reset getopt for the second pass
	optind = 1;
	// Loop through and process the options
	while ((opt = getopt_long(argc, argv, "hd:xsr", long_options, &option_index)) != -1) {
		if (opt == '?') {
			printf("Invalid option. \n");
			usage(EXIT_SUCCESS);
			exitResult=EXIT_SUCCESS;
			goto cleanup;
		}
		switch (option_index) {
			case 0: //help 
				usage(EXIT_SUCCESS);
				exitResult=EXIT_SUCCESS;
				goto cleanup;
			case 1: //device //already handled
				break;
			case 2: //dump
				if (opr != PKTGEN_OPR_MAX) {
					printf("Ignoring other arguments. \n");
				}
				opr = PKTGEN_OPR_DUMP;
				dumpPktGenStructure(ptr);
				break;
			case 3: //register-offset
				if (opr == PKTGEN_OPR_MAX) {
					opr = PKTGEN_OPR_REGISTER_READ;
				} else if (opr == PKTGEN_OPR_REGISTER_WRITE) {
					//ignore
				} else {
					printf("Invalid Arguments\n");
					usage(EXIT_FAILURE);
					exitResult=EXIT_FAILURE;
					goto cleanup;
				}
				registerAddress = strtoul(optarg, NULL, 0);
				if (registerAddress & 0x3) {
					printf("Register addr offset needs to be 32bit alligned - 0x%X\n",registerAddress);
					exitResult=EXIT_FAILURE;
					goto cleanup;
				}
				break;
			case 4: //register-value
				if (opr == PKTGEN_OPR_MAX || opr == PKTGEN_OPR_REGISTER_READ) {
					opr = PKTGEN_OPR_REGISTER_WRITE;
				} else {
					printf("Invalid Arguments\n");
					usage(EXIT_FAILURE);
					exitResult=EXIT_FAILURE;
					goto cleanup;
				}
				value = strtoul(optarg, NULL, 0);
				break;
			case 5: //dest-mac
				if (FAILURE == validateAndSetMAC(&(ptr->dynamic_dest_mac_addr),optarg)) {
					exitResult=EXIT_FAILURE;
					goto cleanup;
				}
				break;
			case 6: //src-mac
				if (FAILURE == validateAndSetMAC(&(ptr->dynamic_src_mac_addr),optarg)) {
					exitResult=EXIT_FAILURE;
					goto cleanup;
				}
				break;
			case 7: //traffic
				if (FAILURE == parse_bool(&cliOption, optarg)) {
					exitResult=EXIT_FAILURE;
					goto cleanup;
				}
				if (setPktGenConfigControlTxTraffic(&(ptr->config), cliOption) == SUCCESS) {
					printf("Tx traffic state set: %s\n",((cliOption==true)?"Enabled":"Disabled"));
				} else {
					printf("Tx traffic state set: Error");
					exitResult=EXIT_FAILURE;
				}
				break;
			case 8: //one-shot
				if (FAILURE == parse_bool(&cliOption, optarg)) {
					exitResult=EXIT_FAILURE;
					goto cleanup;
				}
				if (setPktGenConfigControlOneShotMode(&(ptr->config), cliOption) == SUCCESS) {
					printf("One Shot mode set: %s\n",((cliOption==true)?"Enabled":"Disabled"));
				} else {
					printf("OneShot Mode set: Error");
					exitResult=EXIT_FAILURE;
				}
				break;
			case 9: //soft-reset
				printf("Executing soft reset.");
				setPktGenConfigControlSoftReset(&(ptr->config), true);
				wait = 5;
				while (wait>0) {
					printf("."); sleep(1); wait --;
				}
				printf(". Done.\n");
				setPktGenConfigControlSoftReset(&(ptr->config), false);
				break;
			case 10: //packet-checker
				if (FAILURE == parse_bool(&cliOption, optarg)) {
					exitResult=EXIT_FAILURE;
					goto cleanup;
				}
				if (setPktGenConfigControlPktChecker(&(ptr->config), cliOption) == SUCCESS) {
					printf("Pkt Checker set: %s\n",((cliOption==true)?"Enabled":"Disabled"));
				} else {
					printf("Pkt Checker set: Error");
					exitResult=EXIT_FAILURE;
				}
				break;
			case 11: //cntr-snapshot
				setPktGenConfigControlCntrSnapshot(&(ptr->config), true);
				sleep(1);
				setPktGenConfigControlCntrSnapshot(&(ptr->config), false);
				printf("Counter snapshot: Success\n");
				break;
			case 12: //cntr-clear
				setPktGenConfigControlCntrClear(&(ptr->config), true);
				sleep(1);
				setPktGenConfigControlCntrClear(&(ptr->config), false);
				printf("Clearing Counters: Success\n");
				break;
			case 13: //cntr-internal-clear
				setPktGenConfigControlCntrInternalClear(&(ptr->config), true);
				sleep(1);
				setPktGenConfigControlCntrInternalClear(&(ptr->config), false);
				printf("Clear Internal Counters: Success\n");
				break;
			case 14: //fixed-gap
				if (FAILURE == parse_bool(&cliOption, optarg)) {
					exitResult=EXIT_FAILURE;
					goto cleanup;
				}
				if (setPktGenConfigControlFixedGap(&(ptr->config), cliOption) == SUCCESS) {
					printf("Fixed Gap set: %s\n",((cliOption==true)?"Enabled":"Disabled"));
				} else {
					printf("Fixed Gap set: Error");
					exitResult=EXIT_FAILURE;
				}
				break;
			case 15: //pkt-len-mode
				value = strtoul(optarg, NULL, 0);
				if (setPktGenConfigControlPktLengthMode(&(ptr->config), value) == SUCCESS) {
					printf("Packet length mode set: %d\n", value);
				} else {
					printf("Packet length mode set: Error");
					exitResult=EXIT_FAILURE;
				}
				break;
			case 16: //num-idle-cycles
				value = strtoul(optarg, NULL, 0);
				if (setPktGenConfigControlNumIdleCycles(&(ptr->config), value) == SUCCESS) {
					printf("Number of Idle Cycles set: %d\n", value);
				} else {
					printf("Number of Idle Cycles set: Error");
					exitResult=EXIT_FAILURE;
				}
				break;
			case 17: //tx-pkt-size
				value = strtoul(optarg, NULL, 0);
				value = value/num_words;
				if (setPktGenPktSizeConfigTxPacketSize(&(ptr->pkt_size_config), value) == SUCCESS) {
					printf("Tx Packet Size set: %d\n", value * num_words);
				} else {
					printf("Tx Packet Size set: Error\n");
					exitResult=EXIT_FAILURE;
				}
				break;
			case 18: //tx-max-pkt-size
				value = strtoul(optarg, NULL, 0);
				value = value/num_words;
				if (setPktGenPktSizeConfigTxMaxPacketSize(&(ptr->pkt_size_config), value) == SUCCESS) {
					printf("Max Tx Packet Size set: %d\n", value * num_words);
				} else {
					printf("Max Tx Packet Size set: Error\n");
					exitResult=EXIT_FAILURE;
				}

				break;
			case 19: //num-packets
				value = strtoul(optarg, NULL, 0);
				ptr->num_packets = value;
				break;
			default: 
				printf("Unknown option : %d\n", option_index);
				usage(EXIT_FAILURE);
				exitResult=EXIT_FAILURE;
				goto cleanup;
		}

	}
	switch (opr) {
		case PKTGEN_OPR_REGISTER_WRITE:
			/*printf("Reg Write - Addr: 0x%p offset: 0x%X Value: 0x%x. Old: 0x%x ", ((uint32*)((uint8*)ptr + registerAddress)), registerAddress, value,
					*((uint32*)((uint8*)ptr + registerAddress))); */
			*((uint32*)((uint8*)ptr + registerAddress)) = value;
			printf("0x%08x\t0x%08x\n", registerAddress, *((uint32*)((uint8*)ptr + registerAddress)));
			break;
		case PKTGEN_OPR_REGISTER_READ:
			printf("0x%08x\t0x%08x\n", registerAddress, *((uint32*)((uint8*)ptr + registerAddress)));
			break;
		default:
			break;
	}

cleanup: 
	/* clean up */
	munmap(ptr, map_size);
	close(fd);

	return exitResult;
}
