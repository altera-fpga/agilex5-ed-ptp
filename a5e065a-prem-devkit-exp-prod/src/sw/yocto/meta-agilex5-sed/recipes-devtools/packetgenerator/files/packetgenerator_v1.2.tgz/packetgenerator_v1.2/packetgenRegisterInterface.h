/*********************************************************************************
 * **                                                                           **
 * ** ALTERA CONFIDENTIAL                                                       **
 * **                                                                           **
 * ** Copyright 2024 Altera/ALTERA Corporation All Rights Reserved.             **
 * **                                                                           **
 * ** The source code contained or described herein and all documents related   **
 * ** to the source code ("Material") are owned by Altera Corporation or its    **
 * ** suppliers or licensors.  Title to the Material remains with Altera        **
 * ** Corporation or its suppliers and licensors.  The Material contains trade  **
 * ** secrets and proprietary and confidential information of Altera or its     **
 * ** suppliers and licensors.  The Material is protected by worldwide          **
 * ** copyright and trade secret laws and treaty provisions.  No part of the    **
 * ** Material may be used, copied, reproduced, modified, published, uploaded,  **
 * ** posted, transmitted, distributed, or disclosed in any way without Altera's**
 * ** prior express written permission.                                         **
 * **                                                                           **
 * ** No license under any patent, copyright, trade secret or other             **
 * ** intelectual property right is granted to or conferred upon you by         **
 * ** disclosure or delivery of the Materials, either expressly, by             **
 * ** implication, inducement, estoppel or otherwise.  Any license under such   **
 * ** intelectual property rights must be express and approved by Altera in     **
 * ** writing.                                                                  **
 * **                                                                           **
 * ** Application - Packet Generator v1.0                                       **
 * ** Author - Krishna Kumar S R                                                **
 * ******************************************************************************/
#ifndef __PKTGEN_REGISTER_INTERFACE_H__
#define __PKTGEN_REGISTER_INTERFACE_H__ 
#include <stdlib.h>
#include "packetgenRegisterMap.h"

int setPktGenConfigControlTxTraffic(pktGenConfigControl_t *pControl, bool state);
int setPktGenConfigControlOneShotMode(pktGenConfigControl_t *pControl, bool state);
int setPktGenConfigControlSoftReset(pktGenConfigControl_t *pControl, bool state);
int setPktGenConfigControlDynamicMode(pktGenConfigControl_t *pControl, bool state);
int setPktGenConfigControlPktChecker(pktGenConfigControl_t *pControl, bool state);
int setPktGenConfigControlCntrSnapshot(pktGenConfigControl_t *pControl, bool state);
int setPktGenConfigControlCntrClear(pktGenConfigControl_t *pControl, bool state);
int setPktGenConfigControlCntrInternalClear(pktGenConfigControl_t *pControl, bool state);
int setPktGenConfigControlFixedGap(pktGenConfigControl_t *pControl, bool state);
int setPktGenConfigControlPktLengthMode(pktGenConfigControl_t *pControl, uint32 val);
int setPktGenConfigControlNumIdleCycles(pktGenConfigControl_t *pControl, uint32 cycles);
int setPktGenPktSizeConfigTxPacketSize(pktGenPktSizeConfig_t *pControl, uint32 size);
int setPktGenPktSizeConfigTxMaxPacketSize(pktGenPktSizeConfig_t *pControl, uint32 size);

int validateAndSetMAC(mac_address *macAddr, const char *mac);

#endif //__PKTGEN_REGISTER_INTERFACE_H
