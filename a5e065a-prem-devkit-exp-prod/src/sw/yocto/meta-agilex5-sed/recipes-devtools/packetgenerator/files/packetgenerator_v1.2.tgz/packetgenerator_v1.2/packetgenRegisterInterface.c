/*********************************************************************************
 * **                                                                           **
 * ** ALTERA CONFIDENTIAL                                                       **
 * **                                                                           **
 * ** Copyright 2024 Altera/ALTERA Corporation All Rights Reserved.             **
 * **                                                                           **
 * ** The source code contained or described herein and all documents related   **
 * ** to the source code ("Material") are owned by Altera Corporation or its    **
 * ** suppliers or licensors.  Title to the Material remains with Altera        **
 * ** Corporation or its suppliers and licensors.  The Material contains trade  **
 * ** secrets and proprietary and confidential information of Altera or its     **
 * ** suppliers and licensors.  The Material is protected by worldwide          **
 * ** copyright and trade secret laws and treaty provisions.  No part of the    **
 * ** Material may be used, copied, reproduced, modified, published, uploaded,  **
 * ** posted, transmitted, distributed, or disclosed in any way without Altera's**
 * ** prior express written permission.                                         **
 * **                                                                           **
 * ** No license under any patent, copyright, trade secret or other             **
 * ** intelectual property right is granted to or conferred upon you by         **
 * ** disclosure or delivery of the Materials, either expressly, by             **
 * ** implication, inducement, estoppel or otherwise.  Any license under such   **
 * ** intelectual property rights must be express and approved by Altera in     **
 * ** writing.                                                                  **
 * **                                                                           **
 * ** Application - Packet Generator v1.0                                       **
 * ** Author - Krishna Kumar S R                                                **
 * ******************************************************************************/
#include "packetgenRegisterMap.h"
#include "packetgenRegisterInterface.h"
#include <stdbool.h>
#include <stdio.h>
#include <unistd.h>

#define TRUE 1
#define FALSE 0
/**
 * @brief Sets the configuration control for transmitting traffic in the packet generator.
 *
 * This function allows the user to set the configuration control for transmitting traffic in the packet generator.
 * The configuration control determines how the packet generator will transmit traffic, such as the packet size, rate, and pattern.
 *
 * @param pControl The configuration control where value is to be set.
 * @param state Set or Reset
 *
 * @return SUCCESS or FAILURE
 */
int setPktGenConfigControlTxTraffic(pktGenConfigControl_t *pControl, bool state)
{
	pktGenConfigControl_t control;
	(void) setPktGenConfigControlDynamicMode(pControl, TRUE);
	control.value = pControl->value;
	if (state) {
		PKTGEN_CONFIG_CONTROL_TX_TRAFFIC_SET(control.genconfig.tx_traffic);
	} else {
		PKTGEN_CONFIG_CONTROL_TX_TRAFFIC_RESET(control.genconfig.tx_traffic);
	}
	pControl->value = control.value;
	return SUCCESS;
}
/**
 * @brief Sets the configuration control to enable one-shot mode for the packet generator.
 *
 * This function sets the configuration control to enable one-shot mode for the packet generator.
 * In one-shot mode, the packet generator will generate a single packet and then stop.
 * This is useful for scenarios where only a single packet needs to be generated.
 *
 * @param pControl The configuration control where value is to be set.
 * @param state Set or Reset
 * @return SUCCESS or FAILURE
 */
int setPktGenConfigControlOneShotMode(pktGenConfigControl_t *pControl, bool state)
{
	pktGenConfigControl_t control;
	control.value = pControl->value;
	if (state) {
		PKTGEN_CONFIG_CONTROL_ONE_SHOT_MODE_SET(control.genconfig.one_shot_mode);
	} else {
		PKTGEN_CONFIG_CONTROL_CONTINUOUS_MODE_SET(control.genconfig.one_shot_mode);
	}
	pControl->value = control.value;
	return SUCCESS;
}
/**
 * @brief Sets the configuration control for the soft reset of the packet generator.
 *
 * This function is used to set the configuration control for performing a soft reset
 * of the packet generator. A soft reset allows the packet generator to be reset without
 * affecting other system components. The configuration control determines the behavior
 * of the soft reset operation.
 *
 * @param pControl The configuration control where value is to be set.
 * @param state Set or Reset
 * @return SUCCESS or FAILURE
 */
int setPktGenConfigControlSoftReset(pktGenConfigControl_t *pControl, bool state)
{
	pktGenConfigControl_t control;
	control.value = pControl->value;
	if (state) {
		PKTGEN_CONFIG_CONTROL_SOFT_RESET_SET(control.genconfig.pktgen_soft_reset);
	} else {
		PKTGEN_CONFIG_CONTROL_SOFT_RESET_RESET(control.genconfig.pktgen_soft_reset);
	}
	pControl->value = control.value;
	return SUCCESS;
}
/**
 * @brief Sets the configuration control for the dynamic mode of the packet generator.
 *
 * Sets the configuration control for dynamic mode for the packet generator.
 * In dynamic mode, the packet generator creates packets with different sizes.
 * This allows for more efficient and adaptive packet generation.
 *
 * @param pControl The configuration control where value is to be set.
 * @param state Set or Reset
 * @return SUCCESS or FAILURE
 */

int setPktGenConfigControlDynamicMode(pktGenConfigControl_t *pControl, bool state)
{
	pktGenConfigControl_t control;
	control.value = pControl->value;
	if (state) {
		PKTGEN_CONFIG_CONTROL_DYNAMIC_MODE_SET(control.genconfig.dynamic_mode_pktgen);
	} else {
		PKTGEN_CONFIG_CONTROL_DYNAMIC_MODE_RESET(control.genconfig.dynamic_mode_pktgen);
	}
	pControl->value = control.value;
	return SUCCESS;
}
/**
 * @brief Sets the configuration for the packet generator control packet checker.
 *
 * This function is used to set the configuration parameters for the packet generator control packet checker.
 * The control packet checker is responsible for validating control packets generated by the packet generator.
 * It ensures that the control packets adhere to the specified format and contain the required fields.
 *
 * @param pControl The configuration control where value is to be set.
 * @param state Set or Reset
 * @return SUCCESS or FAILURE
 */
int setPktGenConfigControlPktChecker(pktGenConfigControl_t *pControl, bool state)
{
	pktGenConfigControl_t control;
	control.value = pControl->value;
	if (state) {
		PKTGEN_CONFIG_CONTROL_PKT_CHECKER_SET(control.genconfig.pkt_checker);
	} else {
		PKTGEN_CONFIG_CONTROL_PKT_CHECKER_RESET(control.genconfig.pkt_checker);
	}
	pControl->value = control.value;
	return SUCCESS;
}
/**
 * @brief Sets the configuration control counter snapshot for the PktGen module.
 *
 * This function sets the configuration control counter snapshot for the PktGen module.
 * The configuration control counter snapshot is used to take a snapshop of the counters.
 * It allows for easy comparison to previous counter snapshots.
 *
 * @param pControl The configuration control where value is to be set.
 * @param state Set or Reset
 * @return SUCCESS or FAILURE
 */
int setPktGenConfigControlCntrSnapshot(pktGenConfigControl_t *pControl, bool state)
{
	pktGenConfigControl_t control;
	control.value = pControl->value;
	if (state) {
		PKTGEN_CONFIG_CONTROL_CNTR_SNAPSHOT_SET(control.genconfig.cntr_snapshot);
	} else {
		PKTGEN_CONFIG_CONTROL_CNTR_SNAPSHOT_RESET(control.genconfig.cntr_snapshot);
	}
	pControl->value = control.value;
	return SUCCESS;
}
/**
 * @brief Sets the configuration control counter clear for the PktGen module.
 *
 * This function sets the configuration control counter clear for the PktGen module.
 * The configuration control counter clear is used to clear all counters to enable
 * counter to run from 0
 *
 * @param pControl The configuration control where value is to be set.
 * @param state Set or Reset
 * @return SUCCESS or FAILURE
 */
int setPktGenConfigControlCntrClear(pktGenConfigControl_t *pControl, bool state)
{
	pktGenConfigControl_t control;
	control.value = pControl->value;
	if (state) {
		PKTGEN_CONFIG_CONTROL_CNTR_CLEAR_SET(control.genconfig.cntr_clear);
	} else {
		PKTGEN_CONFIG_CONTROL_CNTR_CLEAR_RESET(control.genconfig.cntr_clear);
	}
	pControl->value = control.value;
	return SUCCESS;
}

/**
 * @brief Clears the internal control counter for the PktGen configuration.
 *
 * This function clears the internal control counter for the PktGen configuration.
 * The internal control counter keeps track of certain configuration settings.
 * Clearing the counter allows for a fresh start when configuring the PktGen module.
 *
 * @param pControl The configuration control where value is to be set.
 * @param state Set or Reset
 * @return SUCCESS or FAILURE
 */
int setPktGenConfigControlCntrInternalClear(pktGenConfigControl_t *pControl, bool state)
{
	pktGenConfigControl_t control;
	control.value = pControl->value;
	if (state) {
		PKTGEN_CONFIG_CONTROL_CNTR_INTERNAL_CLEAR_SET(control.genconfig.cntr_internal_clear);
	} else {
		PKTGEN_CONFIG_CONTROL_CNTR_INTERNAL_CLEAR_RESET(control.genconfig.cntr_internal_clear);
	}
	pControl->value = control.value;
	return SUCCESS;
}

/**
 * @brief Sets the state of the fixed gap in the packet generator configuration control.
 *
 * This function sets the state of the fixed gap in the packet generator configuration control
 * specified by the parameter `pControl`. The state is determined by the `state` parameter,
 * where `true` represents the enabled state and `false` represents the disabled state.
 *
 * @param pControl Pointer to the packet generator configuration control structure.
 * @param state    The state of the fixed gap (true for enabled, false for disabled).
 * @return SUCCESS or FAILURE
 */
int setPktGenConfigControlFixedGap(pktGenConfigControl_t *pControl, bool state)
{
	pktGenConfigControl_t control;
	control.value = pControl->value;
	if (state) {
		PKTGEN_CONFIG_CONTROL_FIXED_GAP_SET(control.genconfig.fixed_gap);
	} else {
		PKTGEN_CONFIG_CONTROL_FIXED_GAP_RESET(control.genconfig.fixed_gap);
	}
	pControl->value = control.value;
	return SUCCESS;
}
/**
 * @brief Sets the packet generation configuration control packet length.
 *
 * This function is used to set the mode for controlling the length of the control packets
 * in the packet generation configuration. The control packet length mode determines how
 * the length of the control packets is determined during packet generation.
 *
 * @param pControl Pointer to the packet generator configuration control structure.
 * @param val      The length of the packet
 * @return SUCCESS or FAILURE
 */
int setPktGenConfigControlPktLengthMode(pktGenConfigControl_t *pControl, uint32 val)
{
	pktGenConfigControl_t control;
	control.value = pControl->value;
	if (val == PKTGEN_CONFIG_CONTROL_PKT_LENGTH_MODE_FIXED_LENGTH || 
			val == PKTGEN_CONFIG_CONTROL_PKT_LENGTH_MODE_INCR_LENGTH) {
		control.genconfig.pkt_length_mode = val & PKTGEN_2BIT_MASK;
	} else {
		return FAILURE;
	}
	pControl->value = control.value;
	return SUCCESS;
}

/**
 * @brief Sets the number of idle cycles for the packet generator configuration control.
 *
 * This function sets the number of idle cycles for the packet generator configuration control.
 *
 * @param pControl Pointer to the packet generator configuration control structure.
 * @param cycles Number of idle cycles to set.
 * @return SUCCESS or FAILURE
 */
int setPktGenConfigControlNumIdleCycles(pktGenConfigControl_t *pControl, uint32 cycles)
{
	pktGenConfigControl_t control;
	control.value = pControl->value;
	control.genconfig.num_idle_cycles = cycles & PKTGEN_8BIT_MASK;
	pControl->value = control.value;
	return SUCCESS;
}

/**
 * @brief Sets the packet size configuration for transmitting packets.
 *
 * This function sets the packet size configuration for transmitting packets in the packet generator.
 *
 * @param pControl Pointer to the pktGenPktSizeConfig_t structure that holds the packet size configuration.
 * @param size The size of the packet to be transmitted.
 * @return SUCCESS or FAILURE
 */
int setPktGenPktSizeConfigTxPacketSize(pktGenPktSizeConfig_t *pControl, uint32 size)
{
	pktGenPktSizeConfig_t control;
	control.value = pControl->value;
	control.sizecfg.tx_packet_size = size & PKTGEN_PKTSIZE_CONFIG_TX_PACKET_SIZE_MASK;
	pControl->value = control.value;
	return SUCCESS;
}
/**
 * @brief Configures the maximum packet size for the transmission in the PktGen module.
 *
 * This function sets the maximum packet size that can be transmitted using the PktGen module.
 * The maximum packet size determines the size of the buffer allocated for transmitting packets.
 *
 * @param pControl Pointer to the pktGenPktSizeConfig_t structure that holds the packet size configuration.
 * @param size The maximum size of the packet to be transmitted.
 * @return SUCCESS or FAILURE
 */
int setPktGenPktSizeConfigTxMaxPacketSize(pktGenPktSizeConfig_t *pControl, uint32 size)
{
	pktGenPktSizeConfig_t control;
	control.value = pControl->value;
	control.sizecfg.tx_packet_size_max = size & PKTGEN_PKTSIZE_CONFIG_TX_PACKET_SIZE_MASK;
	pControl->value = control.value;
	return SUCCESS;
}

/**
 * @brief Validates and sets the MAC address.
 *
 * This function takes a pointer to a `mac_address` structure and a string representing a MAC address,
 * and validates the MAC address format. If the format is valid, it sets the MAC address in the `macAddr`
 * structure.
 *
 * @param macAddr Pointer to the `mac_address` structure to store the MAC address.
 * @param mac String representing the MAC address to validate and set.
 * @return int Returns 0 if the MAC address is valid and set successfully, otherwise returns a non-zero value.
 */
int validateAndSetMAC(mac_address *macAddr, const char *mac) {
	mac_address addr;
	addr.val.high = addr.val.low = 0;

    // Parse the MAC address string and store it in addr
	if (sscanf(mac, "%hhx:%hhx:%hhx:%hhx:%hhx:%hhx",
				(unsigned char *)&(addr.mac.byte_0), (unsigned char *)&(addr.mac.byte_1), (unsigned char *)&(addr.mac.byte_2),
				(unsigned char *)&(addr.mac.byte_3), (unsigned char *)&(addr.mac.byte_4), (unsigned char *)&(addr.mac.byte_5)) == 6) {
#ifdef DEBUG
		printf("%s:%d Mac: 0x%x 0x%x %02x:%02x:%02x:%02x:%02x:%02x\n", __FUNCTION__,__LINE__, addr.val.high, addr.val.low,
				(unsigned int)(addr.mac.byte_0), (unsigned int)(addr.mac.byte_1), (unsigned int)(addr.mac.byte_2),
                                (unsigned int)(addr.mac.byte_3), (unsigned int)(addr.mac.byte_4), (unsigned int)(addr.mac.byte_5));
#endif
       // If parsing is successful, set the macAddr values
		macAddr->val.high = addr.val.high;
		sleep(0);
		macAddr->val.low = addr.val.low;
		return SUCCESS;
	} else {
		// If parsing fails, print an error message
		fprintf(stderr, "Invalid MAC address: %s\n", mac);
		return FAILURE;
	}
}

